#!/usr/bin/env bash
file_list=$(git status --porcelain |
  egrep '^A|^M' |
  sed 's/^..//')

case $file_list in
  "")
    echo No files found, skipping Pre-Check hook
    ;;
  *)
    echo Pre-Check hook. . .
    set -x
    bundle exec rubocop --force-exclusion $file_list
esac
